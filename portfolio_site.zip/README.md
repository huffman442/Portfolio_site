# README

This is the github repository for my personal website.

I intend to use this website to show off my web development skills, using 
React, Ruby on Rails, JavaScript, CSS, and whatever else is needed,
probably jQuery.

On this website I intend on having my Resume, Examples of work that I have
done, the Roguelike game that I am working on, and a blog covering Sports 
and what I learned in Academy Pittsburgh.

This website will have a Home page, a blog page, a resume page, and 
different ways to search and sort within those things. Updates to this 
readme will be incoming.

To start I'm using the 'getting started' guide to build the first part of the site, the blog part.

I used this article to help me think about building the blog engine to be better
https://thoughtbot.com/blog/adding-a-blog-to-a-rails-app

Building authentication from scratch:
http://railscasts.com/episodes/250-authentication-from-scratch-revised?autoplay=true

